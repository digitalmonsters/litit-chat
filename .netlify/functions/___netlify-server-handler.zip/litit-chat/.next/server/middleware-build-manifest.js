globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/dada4c93367badb3.js",
    "static/chunks/6d8ec69a5ab63691.js",
    "static/chunks/4fa9e087489d1199.js",
    "static/chunks/2fc3777af3538071.js",
    "static/chunks/turbopack-8f6aa9e38a154ce4.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];