module.exports=[66640,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_api_users_sync_route_actions_f1395bad.js.map