module.exports=[88446,(a,b,c)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_page_actions_59270f43.js.map