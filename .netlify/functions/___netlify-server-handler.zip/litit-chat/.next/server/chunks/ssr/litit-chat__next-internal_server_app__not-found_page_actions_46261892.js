module.exports=[27579,(a,b,c)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app__not-found_page_actions_46261892.js.map