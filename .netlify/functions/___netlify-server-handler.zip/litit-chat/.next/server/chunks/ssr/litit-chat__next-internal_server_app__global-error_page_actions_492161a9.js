module.exports=[28263,(a,b,c)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app__global-error_page_actions_492161a9.js.map