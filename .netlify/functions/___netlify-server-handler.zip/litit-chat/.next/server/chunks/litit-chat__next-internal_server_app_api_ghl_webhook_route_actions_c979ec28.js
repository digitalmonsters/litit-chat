module.exports=[35386,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_api_ghl_webhook_route_actions_c979ec28.js.map