module.exports=[31956,(e,o,d)=>{}];

//# sourceMappingURL=b50d1__next-internal_server_app_api_liveparties_entry_route_actions_b8cca00e.js.map