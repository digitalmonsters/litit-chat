module.exports=[57673,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_api_payments_tip_route_actions_05ec2536.js.map