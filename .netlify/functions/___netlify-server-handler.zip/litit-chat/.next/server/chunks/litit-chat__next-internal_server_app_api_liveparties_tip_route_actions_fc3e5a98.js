module.exports=[57462,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_api_liveparties_tip_route_actions_fc3e5a98.js.map