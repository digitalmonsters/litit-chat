module.exports=[18963,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_api_call_initiate_route_actions_c0070823.js.map