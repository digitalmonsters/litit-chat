module.exports=[80905,(e,o,d)=>{}];

//# sourceMappingURL=b50d1__next-internal_server_app_api_payments_subscribe_route_actions_f3ae27ba.js.map