module.exports=[1891,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_api_ghl_test_route_actions_01ec7777.js.map