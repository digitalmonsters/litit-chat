module.exports=[929,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_api_battles_tip_route_actions_fe3ed3ab.js.map