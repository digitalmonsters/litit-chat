module.exports=[85213,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_favicon_ico_route_actions_4defb0d0.js.map