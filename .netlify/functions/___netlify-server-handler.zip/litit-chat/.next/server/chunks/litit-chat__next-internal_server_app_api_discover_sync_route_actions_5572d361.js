module.exports=[7732,(e,o,d)=>{}];

//# sourceMappingURL=litit-chat__next-internal_server_app_api_discover_sync_route_actions_5572d361.js.map