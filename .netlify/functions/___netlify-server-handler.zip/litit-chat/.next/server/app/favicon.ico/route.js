var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__b89b5a39._.js")
R.c("server/chunks/[root-of-the-server]__a9e8c45d._.js")
R.c("server/chunks/a37d4_next_dist_esm_build_templates_app-route_4a1ff90a.js")
R.c("server/chunks/litit-chat__next-internal_server_app_favicon_ico_route_actions_4defb0d0.js")
R.m(70972)
module.exports=R.m(70972).exports
