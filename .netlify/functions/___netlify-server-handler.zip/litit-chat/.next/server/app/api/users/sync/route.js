var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/sync/route.js")
R.c("server/chunks/[root-of-the-server]__4f5912df._.js")
R.c("server/chunks/[root-of-the-server]__c6436d3c._.js")
R.c("server/chunks/a37d4_e8b3a20b._.js")
R.c("server/chunks/[root-of-the-server]__a9e8c45d._.js")
R.c("server/chunks/litit-chat_lib_firebase_ts_5b35e13b._.js")
R.c("server/chunks/litit-chat__next-internal_server_app_api_users_sync_route_actions_f1395bad.js")
R.m(48253)
module.exports=R.m(48253).exports
