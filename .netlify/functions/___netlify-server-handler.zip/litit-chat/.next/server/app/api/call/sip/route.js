var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/call/sip/route.js")
R.c("server/chunks/[root-of-the-server]__44c1c973._.js")
R.c("server/chunks/[root-of-the-server]__4f5912df._.js")
R.c("server/chunks/a37d4_e8b3a20b._.js")
R.c("server/chunks/[root-of-the-server]__a9e8c45d._.js")
R.c("server/chunks/litit-chat_lib_firebase_ts_5b35e13b._.js")
R.c("server/chunks/litit-chat__next-internal_server_app_api_call_sip_route_actions_9b5dc15e.js")
R.m(95786)
module.exports=R.m(95786).exports
