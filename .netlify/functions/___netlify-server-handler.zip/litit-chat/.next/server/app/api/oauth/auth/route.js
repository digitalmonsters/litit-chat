var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/oauth/auth/route.js")
R.c("server/chunks/[root-of-the-server]__5656f74d._.js")
R.c("server/chunks/[root-of-the-server]__a9e8c45d._.js")
R.c("server/chunks/litit-chat__next-internal_server_app_api_oauth_auth_route_actions_3d80a099.js")
R.m(60326)
module.exports=R.m(60326).exports
