var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/webhook/test/route.js")
R.c("server/chunks/[root-of-the-server]__ac15b5e7._.js")
R.c("server/chunks/[root-of-the-server]__a9e8c45d._.js")
R.c("server/chunks/b50d1__next-internal_server_app_api_payments_webhook_test_route_actions_e1da60a2.js")
R.m(10180)
module.exports=R.m(10180).exports
