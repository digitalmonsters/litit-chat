module.exports=[48655,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_discover_sync_route_actions_6ae243a9.js.map