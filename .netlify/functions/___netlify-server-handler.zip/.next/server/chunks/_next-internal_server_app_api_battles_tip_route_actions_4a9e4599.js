module.exports=[49146,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_battles_tip_route_actions_4a9e4599.js.map