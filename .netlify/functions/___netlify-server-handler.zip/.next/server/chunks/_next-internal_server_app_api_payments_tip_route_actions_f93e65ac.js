module.exports=[75562,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payments_tip_route_actions_f93e65ac.js.map