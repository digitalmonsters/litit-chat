module.exports=[3566,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ghl_webhook_route_actions_c69a833e.js.map