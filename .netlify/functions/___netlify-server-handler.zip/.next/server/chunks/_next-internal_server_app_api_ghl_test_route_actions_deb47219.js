module.exports=[39594,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ghl_test_route_actions_deb47219.js.map