module.exports=[3704,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_call_initiate_route_actions_15039df7.js.map