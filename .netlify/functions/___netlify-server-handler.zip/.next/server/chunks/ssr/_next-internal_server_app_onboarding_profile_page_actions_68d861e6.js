module.exports=[66097,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_onboarding_profile_page_actions_68d861e6.js.map