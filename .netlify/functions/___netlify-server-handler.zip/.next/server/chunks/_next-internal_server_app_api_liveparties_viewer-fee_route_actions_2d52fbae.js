module.exports=[65366,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_liveparties_viewer-fee_route_actions_2d52fbae.js.map