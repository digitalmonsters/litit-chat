module.exports=[27057,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_oauth_auth_route_actions_12e25da5.js.map