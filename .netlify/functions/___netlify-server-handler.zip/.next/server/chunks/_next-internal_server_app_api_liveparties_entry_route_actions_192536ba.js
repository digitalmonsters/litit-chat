module.exports=[95335,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_liveparties_entry_route_actions_192536ba.js.map