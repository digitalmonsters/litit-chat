module.exports=[6873,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_call_token_route_actions_cbce5f37.js.map