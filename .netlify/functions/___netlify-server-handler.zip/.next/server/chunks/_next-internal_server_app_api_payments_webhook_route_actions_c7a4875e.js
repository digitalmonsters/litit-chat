module.exports=[87668,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payments_webhook_route_actions_c7a4875e.js.map