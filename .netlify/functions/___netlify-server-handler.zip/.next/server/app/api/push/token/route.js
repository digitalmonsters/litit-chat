var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/push/token/route.js")
R.c("server/chunks/[root-of-the-server]__39982519._.js")
R.c("server/chunks/[root-of-the-server]__969208a2._.js")
R.c("server/chunks/lib_firebase_ts_96f21a7b._.js")
R.c("server/chunks/node_modules_5cf12a84._.js")
R.c("server/chunks/[root-of-the-server]__b6491784._.js")
R.c("server/chunks/_next-internal_server_app_api_push_token_route_actions_e99e747e.js")
R.m(68461)
module.exports=R.m(68461).exports
