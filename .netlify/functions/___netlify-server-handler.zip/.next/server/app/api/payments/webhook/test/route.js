var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/webhook/test/route.js")
R.c("server/chunks/[root-of-the-server]__f95ac3a0._.js")
R.c("server/chunks/[root-of-the-server]__b6491784._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_webhook_test_route_actions_bee16eae.js")
R.m(58781)
module.exports=R.m(58781).exports
