var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/topup/route.js")
R.c("server/chunks/[root-of-the-server]__969208a2._.js")
R.c("server/chunks/[root-of-the-server]__373266a2._.js")
R.c("server/chunks/[root-of-the-server]__b6491784._.js")
R.c("server/chunks/node_modules_5cf12a84._.js")
R.c("server/chunks/lib_firebase_ts_96f21a7b._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_topup_route_actions_3687e033.js")
R.m(84844)
module.exports=R.m(84844).exports
