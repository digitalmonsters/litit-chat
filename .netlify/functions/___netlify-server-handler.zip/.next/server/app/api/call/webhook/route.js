var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/call/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__969208a2._.js")
R.c("server/chunks/[root-of-the-server]__aae33f0a._.js")
R.c("server/chunks/lib_firebase_ts_96f21a7b._.js")
R.c("server/chunks/node_modules_5cf12a84._.js")
R.c("server/chunks/[root-of-the-server]__b6491784._.js")
R.c("server/chunks/_next-internal_server_app_api_call_webhook_route_actions_4e661d1f.js")
R.m(69475)
module.exports=R.m(69475).exports
