var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/discover/sync/route.js")
R.c("server/chunks/[root-of-the-server]__969208a2._.js")
R.c("server/chunks/[root-of-the-server]__4a1fe8ab._.js")
R.c("server/chunks/node_modules_5cf12a84._.js")
R.c("server/chunks/[root-of-the-server]__b6491784._.js")
R.c("server/chunks/lib_firebase_ts_96f21a7b._.js")
R.c("server/chunks/_next-internal_server_app_api_discover_sync_route_actions_6ae243a9.js")
R.m(59283)
module.exports=R.m(59283).exports
