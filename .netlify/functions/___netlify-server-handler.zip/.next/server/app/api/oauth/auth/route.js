var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/oauth/auth/route.js")
R.c("server/chunks/[root-of-the-server]__bc87eb7d._.js")
R.c("server/chunks/[root-of-the-server]__b6491784._.js")
R.c("server/chunks/_next-internal_server_app_api_oauth_auth_route_actions_12e25da5.js")
R.m(76743)
module.exports=R.m(76743).exports
